<?php
// @codingStandardsIgnoreFile
/**
 * MIME Alias Handling
 *
 * @package blob-mimes
 * @version 0.1.2
 *
 * @see {https://core.trac.wordpress.org/ticket/39963}
 * @see {https://core.trac.wordpress.org/ticket/40175}
 * @see {https://github.com/Blobfolio/blob-mimes/tree/master/build/WordPress}
 * @see {https://github.com/Blobfolio/blob-mimes}
 *
 * @wordpress-plugin
 * Plugin Name: MIME Alias Handling
 * Plugin URI: https://core.trac.wordpress.org/ticket/39963
 * Description: Feature Plugin integrating MIME alias support into the file upload validation process.
 * Version: 0.1.2
 * Author: Blobfolio, LLC
 * Author URI: https://blobfolio.com/
 * License: WTFPL
 * License URI: http://www.wtfpl.net/
 */

/**
 * Do not execute this file directly.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}



/**
 * Disable the plugin if the data file exists natively.
 */

if (
	file_exists( ABSPATH . WPINC . '/media-mimes.php' )
) {
	blob_mimes_deactivate();
}



/**
 * Safety First!
 *
 * Check to make sure this plugin is still needed.
 *
 * @since 0.1.0
 *
 * @return void Nothing.
 */
function blob_mimes_deactivate() {
	// This plugin should be de-activated if any components
	// have landed in the core.
	if (
		file_exists( ABSPATH . WPINC . '/media-mimes.php' ) ||
		function_exists( 'wp_check_real_filetype' ) ||
		function_exists( 'wp_check_mime_alias' )
	) {
		require_once( ABSPATH . '/wp-admin/includes/plugin.php' );
		deactivate_plugins( dirname( __FILE__ ) . '/index.php' );
	}
	// Otherwise let's pull in the functions!
	else {
		require_once( dirname( __FILE__ ) . '/functions.php' );
	}
}
add_action ( 'plugins_loaded', 'blob_mimes_deactivate', 5, 0 );



/**
 * Override File Validation
 *
 * In plugin form this has to be executed via
 * filter, but an actual merger would instead
 * see a rewrite of wp_check_filetype_and_ext()
 *
 * @since 0.1.0
 *
 * @see wp_check_filetype_and_ext()
 *
 * @param  array  $checked Previous check status.
 * @param string $file File path.
 * @param string $filename File name.
 * @param array  $mimes Mimes.
 * @return array    Checked status.
 */
function blob_mimes_check_filetype_and_ext( $checked, $file, $filename, $mimes ) {
	// We don't care what WP has already done.
	$proper_filename = false;

	// Do basic extension validation and MIME mapping.
	$wp_filetype = wp_check_real_filetype( $file, $filename, $mimes );
	$ext = $wp_filetype['ext'];
	$type = $wp_filetype['type'];

	// We can't do any further validation without a file to work with.
	if ( ! file_exists( $file ) ) {
		return compact( 'ext', 'type', 'proper_filename' );
	}

	// If the type is valid, should we be renaming the file?
	if ( false !== $ext && false !== $type ) {
		$filename_parts = explode( '.', $filename );
		array_pop( $filename_parts );
		$filename_parts[] = $ext;
		$new_filename = implode( '.', $filename_parts );
		if ( $filename !== $new_filename ) {
			$proper_filename = implode( '.', $filename_parts );
		}
	}

	return compact( 'ext', 'type', 'proper_filename' );
}
add_filter( 'wp_check_filetype_and_ext', 'blob_mimes_check_filetype_and_ext', 10, 4 );



// Update handler.
@require_once( dirname( __FILE__ ) . '/functions-updates.php' );
